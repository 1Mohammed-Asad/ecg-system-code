
import React from 'react';
import { Clock, AlertTriangle, ShieldCheck, FileText, Activity, Zap, HeartPulse } from 'lucide-react';
import { EcgReport, ReportLevel } from '../types';

interface ReportCardProps {
    report: EcgReport;
}

const ReportCard: React.FC<ReportCardProps> = ({ report }) => {
    const getAlertColors = (level: ReportLevel) => {
        switch (level) {
            case 'Critical': return 'border-red-500 bg-red-900/50 text-red-300';
            case 'Warning': return 'border-yellow-500 bg-yellow-900/50 text-yellow-300';
            case 'Normal': return 'border-green-500 bg-green-900/50 text-green-300';
            default: return 'border-gray-500 bg-gray-700/50 text-gray-300';
        }
    };

    const getAlertIcon = (level: ReportLevel) => {
        switch (level) {
            case 'Critical': return <AlertTriangle className="w-10 h-10 text-red-500" />;
            case 'Warning': return <AlertTriangle className="w-10 h-10 text-yellow-500" />;
            case 'Normal': return <ShieldCheck className="w-10 h-10 text-green-500" />;
            default: return <Activity className="w-10 h-10 text-gray-400" />;
        }
    };
    
    const reportDate = new Date(report.timestamp);

    return (
        <div className={`p-4 rounded-lg border ${getAlertColors(report.level)}`}>
            <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">{getAlertIcon(report.level)}</div>
                <div className="flex-1">
                    <div className="flex justify-between items-start flex-wrap gap-2">
                        <h3 className="text-lg font-bold">{report.condition}</h3>
                        <span className="text-xs text-gray-400 flex items-center shrink-0">
                            <Clock size={12} className="mr-1" />
                            {reportDate.toLocaleString()}
                        </span>
                    </div>
                    
                    <div className="mt-3 space-y-2 text-sm">
                      <p><span className="font-semibold text-gray-200">Summary:</span> {report.summary}</p>
                      <p className="font-bold"><span className="font-semibold text-gray-200">Recommendation:</span> {report.recommendation}</p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono bg-gray-900/70 p-3 rounded-md">
                       <div className="flex items-center" title="Confidence">
                           <ShieldCheck size={14} className="mr-2 text-cyan-400"/>
                           <span>Conf: {report.confidence.toFixed(1)}%</span>
                       </div>
                       <div className="flex items-center" title="Emergency Probability">
                           <Zap size={14} className="mr-2 text-yellow-400"/>
                           <span>Emergency: {report.emergencyProbability.toFixed(1)}%</span>
                       </div>
                       <div className="flex items-center" title="Heart Rate">
                           <HeartPulse size={14} className="mr-2 text-red-400"/>
                           <span>{report.heartRate.toFixed(0)} BPM</span>
                       </div>
                    </div>
                    
                    <div className="mt-3 text-xs text-gray-400 flex items-center">
                       <FileText size={12} className="mr-1" /> Scanned File: {report.fileName}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReportCard;
