
import React, { useState, useEffect, useCallback } from 'react';
import { EcgReport } from '../types';
import { getHistory, deleteReport } from '../services/storageService';
import HistoryItem from './HistoryItem';

interface HistoryPageProps {
    showToast: (message: string) => void;
}

const HistoryPage: React.FC<HistoryPageProps> = ({ showToast }) => {
    const [history, setHistory] = useState<EcgReport[]>([]);

    useEffect(() => {
        setHistory(getHistory());
    }, []);

    const handleDelete = useCallback((id: string) => {
        const newHistory = deleteReport(id);
        setHistory(newHistory);
        showToast('Scan successfully deleted.');
    }, [showToast]);

    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-cyan-300">Scan History</h2>
            <div className="space-y-4">
                {history.length > 0 ? (
                    history.map(item => <HistoryItem key={item.id} item={item} onDelete={handleDelete} />)
                ) : (
                    <p className="text-center text-gray-400 py-8">No scans found. Go to the Scanner to analyze an ECG file.</p>
                )}
            </div>
        </div>
    );
};

export default HistoryPage;
