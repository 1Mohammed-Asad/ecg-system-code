import React from 'react';
import { Stethoscope, User, Share2, Download } from 'lucide-react';
import { Page } from '../App';

interface HeaderProps {
    currentPage: Page;
    onNavClick: (page: Page) => void;
    onInstallClick: () => void;
    showInstallButton: boolean;
    userId: string;
    showToast: (message: string) => void;
}

const Header: React.FC<HeaderProps> = ({ currentPage, onNavClick, onInstallClick, showInstallButton, userId, showToast }) => {
    
    const copyUserId = () => {
        if (!userId) return;
        navigator.clipboard.writeText(userId).then(() => {
            showToast('User ID copied to clipboard!');
        }).catch(err => {
            console.error('Failed to copy user ID: ', err);
            showToast('Failed to copy ID.');
        });
    };

    return (
        <header>
            <div className="flex justify-between items-center flex-wrap gap-4">
                <div className="flex items-center space-x-3">
                    <Stethoscope className="w-8 h-8 text-cyan-400" />
                    <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white">ECG Scanner Analyzer</h1>
                </div>
                <nav className="flex items-center space-x-2 md:space-x-4">
                    <button 
                        onClick={() => onNavClick('scanner')} 
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentPage === 'scanner' ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>
                        Scanner
                    </button>
                    <button 
                        onClick={() => onNavClick('history')} 
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentPage === 'history' ? 'bg-cyan-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>
                        History
                    </button>
                    {showInstallButton && (
                        <button 
                            onClick={onInstallClick} 
                            className="flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium bg-indigo-600 hover:bg-indigo-700 transition-colors"
                            title="Install App">
                            <Download size={16} />
                            <span>Install</span>
                        </button>
                    )}
                </nav>
            </div>
            <div className="mt-4 flex items-center justify-end space-x-2 text-xs text-gray-400 bg-gray-800 p-2 rounded-md">
                <User size={14} />
                <span className="font-mono break-all">User ID: {userId || 'Loading...'}</span>
                <button onClick={copyUserId} title="Copy User ID">
                    <Share2 size={14} className="hover:text-cyan-400 transition-colors" />
                </button>
            </div>
        </header>
    );
};

export default Header;