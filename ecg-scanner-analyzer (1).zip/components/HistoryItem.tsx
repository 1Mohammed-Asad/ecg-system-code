
import React, { useState } from 'react';
import { EcgReport, ReportLevel } from '../types';
import { ChevronDown, ChevronUp, Trash2, ImageIcon, FileIcon } from 'lucide-react';
import ReportCard from './ReportCard';

interface HistoryItemProps {
    item: EcgReport;
    onDelete: (id: string) => void;
}

const HistoryItem: React.FC<HistoryItemProps> = ({ item, onDelete }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const getBorderColor = (level: ReportLevel) => {
        switch (level) {
            case 'Critical': return 'border-l-4 border-red-500';
            case 'Warning': return 'border-l-4 border-yellow-500';
            case 'Normal': return 'border-l-4 border-green-500';
            default: return 'border-l-4 border-gray-500';
        }
    };

    const itemDate = new Date(item.timestamp);
    const isImage = item.fileType?.startsWith('image/');

    return (
        <div className={`bg-gray-700 rounded-lg transition-all duration-300 ${getBorderColor(item.level)}`}>
            <div className="p-4 flex items-center justify-between cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
                <div className="flex-1 flex items-center space-x-4 overflow-hidden">
                    <div className="flex-shrink-0">
                        {isImage ? <ImageIcon className="text-gray-400" /> : <FileIcon className="text-gray-400" />}
                    </div>
                    <div className="overflow-hidden">
                        <p className="font-bold text-white truncate">{item.condition}</p>
                        <p className="text-sm text-gray-300 truncate">File: {item.fileName}</p>
                    </div>
                </div>
                <div className="text-right mx-4 hidden sm:block">
                     <p className="text-xs text-gray-400">{itemDate.toLocaleDateString()}</p>
                     <p className="text-xs text-gray-400">{itemDate.toLocaleTimeString()}</p>
                </div>
                <div className="flex items-center space-x-2">
                    <button onClick={(e) => { e.stopPropagation(); onDelete(item.id); }} className="p-2 text-gray-400 hover:text-red-500 transition-colors" title="Delete Scan">
                        <Trash2 size={18} />
                    </button>
                    {isExpanded ? <ChevronUp /> : <ChevronDown />}
                </div>
            </div>
            {isExpanded && (
                <div className="p-4 border-t border-gray-600 space-y-4 animate-fade-in">
                    <div>
                        <h4 className="font-semibold text-cyan-300 mb-2">AI Analysis Report</h4>
                        <ReportCard report={item} />
                    </div>
                    <div>
                        <h4 className="font-semibold text-cyan-300 mb-2">Scanned File Preview</h4>
                        <div className="bg-gray-900 rounded-lg p-2 flex items-center justify-center min-h-[250px]">
                            {isImage && item.fileDataUrl ? (
                                <img src={item.fileDataUrl} alt="ECG Scan Preview" className="max-h-[400px] max-w-full object-contain rounded"/>
                            ) : (
                                <div className="text-center text-gray-400">
                                    <FileIcon size={48} className="mx-auto mb-2"/>
                                    <p>Preview not available for this file type.</p>
                                    <p className="text-xs">{item.fileName}</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
             <style>{`
                .animate-fade-in {
                    animation: fadeIn 0.5s ease-in-out;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
};

export default HistoryItem;
