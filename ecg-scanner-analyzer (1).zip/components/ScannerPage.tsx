import React, { useState, useCallback } from 'react';
import { Upload } from 'lucide-react';
import { EcgReport } from '../types';
import { analyzeEcgFile } from '../services/geminiService';
import { saveReport } from '../services/storageService';
import ReportCard from './ReportCard';
import Spinner from './Spinner';

interface ScannerPageProps {
  showToast: (message: string) => void;
}

const ScannerPage: React.FC<ScannerPageProps> = ({ showToast }) => {
    const [scanResult, setScanResult] = useState<EcgReport | null>(null);
    const [isScanning, setIsScanning] = useState(false);
    const [fileName, setFileName] = useState('');
    const [fileDataUrl, setFileDataUrl] = useState<string | null>(null);
    const [fileType, setFileType] = useState('');
    const [error, setError] = useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
                setError('Only image or PDF files are supported for AI analysis.');
                return;
            }
            setFileName(file.name);
            setFileType(file.type);
            setScanResult(null);
            setError('');

            const reader = new FileReader();
            reader.onloadend = () => {
                setFileDataUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleScan = useCallback(async () => {
        if (!fileDataUrl || !fileName) {
            setError('Please select a file to scan.');
            return;
        }

        setIsScanning(true);
        setScanResult(null);
        setError('');

        try {
            const base64Data = fileDataUrl.split(',')[1];
            const analysis = await analyzeEcgFile(base64Data, fileType);
            
            const newReport: EcgReport = {
                ...analysis,
                id: `scan_${Date.now()}`,
                timestamp: new Date().toISOString(),
                fileName: fileName,
                fileDataUrl: fileDataUrl,
                fileType: fileType,
            };

            setScanResult(newReport);
            saveReport(newReport);
            showToast('Analysis complete and saved to history.');

        } catch (e) {
            const err = e as Error;
            console.error(err);
            setError(err.message || 'An unknown error occurred during analysis.');
            showToast('Analysis Failed.');
        } finally {
            setIsScanning(false);
        }
    }, [fileDataUrl, fileName, fileType, showToast]);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-semibold mb-4 text-cyan-300">New Scan</h2>
                <div className="space-y-6">
                    <div>
                        <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-2">Upload ECG File</label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                <Upload className="mx-auto h-12 w-12 text-gray-500" />
                                <div className="flex text-sm text-gray-400">
                                    <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-700 rounded-md font-medium text-cyan-400 hover:text-cyan-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-gray-800 focus-within:ring-cyan-500 px-2">
                                        <span>Upload a file</span>
                                        <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*,.pdf" />
                                    </label>
                                    <p className="pl-1">or drag and drop</p>
                                </div>
                                <p className="text-xs text-gray-500">Images or PDF files</p>
                            </div>
                        </div>
                        {fileName && <p className="text-sm text-gray-400 mt-2">Selected: {fileName}</p>}
                    </div>
                    {error && <p className="text-sm text-red-400 p-3 bg-red-900/50 rounded-md">{error}</p>}
                    <button
                        onClick={handleScan}
                        disabled={isScanning || !fileDataUrl}
                        className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300"
                    >
                        {isScanning ? <><Spinner /> Analyzing with AI...</> : 'Analyze ECG Now'}
                    </button>
                </div>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg min-h-[300px] flex flex-col justify-center">
                <h2 className="text-xl font-semibold mb-4 text-cyan-300">AI Analysis Report</h2>
                {isScanning && <div className="text-center flex flex-col items-center"><Spinner /><p>Processing ECG data with Gemini. Please wait...</p></div>}
                {!isScanning && !scanResult && (
                    <div className="text-center text-gray-400">
                        <p>Upload a file and click "Analyze" to see the AI-generated report.</p>
                    </div>
                )}
                {scanResult && <ReportCard report={scanResult} />}
            </div>
        </div>
    );
};

export default ScannerPage;