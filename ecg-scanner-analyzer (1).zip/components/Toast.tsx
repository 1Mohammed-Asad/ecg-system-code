
import React from 'react';
import { CheckCircle } from 'lucide-react';

interface ToastProps {
    message: string;
}

const Toast: React.FC<ToastProps> = ({ message }) => {
    return (
        <>
            <div className="fixed bottom-5 right-5 bg-green-600 text-white py-2 px-4 rounded-lg shadow-lg flex items-center animate-fade-in-out">
                <CheckCircle size={20} className="mr-2" />
                <span>{message}</span>
            </div>
            <style>{`
                .animate-fade-in-out {
                    animation: fadeInOut 3s ease-in-out forwards;
                }
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translateY(20px); }
                    10% { opacity: 1; transform: translateY(0); }
                    90% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(20px); }
                }
            `}</style>
        </>
    );
};

export default Toast;
