import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="text-center mt-12 mb-4 px-4 text-xs text-gray-500">
            <p>ECG Scanner Analyzer v2.1. For demonstration purposes only.</p>
            <p>This tool does not provide medical advice. Consult a healthcare professional for any health concerns.</p>
        </footer>
    );
};

export default Footer;