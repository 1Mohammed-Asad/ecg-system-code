import { GoogleGenAI, Type } from "@google/genai";
import { EcgReport, ReportLevel } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const reportSchema = {
  type: Type.OBJECT,
  properties: {
    condition: { type: Type.STRING, description: "The primary medical condition detected, e.g., 'Normal Sinus Rhythm', 'Atrial Fibrillation'." },
    confidence: { type: Type.NUMBER, description: "A percentage (0-100) indicating the model's confidence in the detected condition." },
    emergencyProbability: { type: Type.NUMBER, description: "A percentage (0-100) indicating the likelihood this is a medical emergency." },
    heartRate: { type: Type.NUMBER, description: "The estimated heart rate in beats per minute (BPM)." },
    level: { type: Type.STRING, description: "A severity classification: 'Normal', 'Warning', or 'Critical'." },
    summary: { type: Type.STRING, description: "A concise, one-sentence summary of the findings." },
    recommendation: { type: Type.STRING, description: "A brief recommendation for the user, e.g., 'No immediate action needed.' or 'Consult a cardiologist.'" },
  },
  required: ["condition", "confidence", "emergencyProbability", "heartRate", "level", "summary", "recommendation"],
};


export const analyzeEcgFile = async (base64ImageData: string, mimeType: string): Promise<Omit<EcgReport, 'id' | 'timestamp' | 'fileName' | 'fileDataUrl' | 'fileType'>> => {
  try {
    const filePart = {
      inlineData: {
        data: base64ImageData,
        mimeType: mimeType,
      },
    };

    const textPart = {
      text: "Analyze this ECG file (which could be an image or a PDF). Identify the primary rhythm, heart rate, and any abnormalities. Provide a concise analysis suitable for a patient to understand, formatted as JSON according to the provided schema. Classify the severity as 'Normal', 'Warning', or 'Critical'.",
    };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [textPart, filePart] },
        config: {
          responseMimeType: "application/json",
          responseSchema: reportSchema,
        }
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    
    // Validate the level field
    const validLevels: ReportLevel[] = ['Normal', 'Warning', 'Critical'];
    if (!validLevels.includes(result.level)) {
        console.warn(`Invalid level received: ${result.level}. Defaulting to 'Unknown'.`);
        result.level = 'Unknown';
    }

    return result as Omit<EcgReport, 'id' | 'timestamp' | 'fileName' | 'fileDataUrl' | 'fileType'>;
  } catch (error) {
    console.error("Error analyzing ECG with Gemini:", error);
    if (error instanceof Error && error.message.includes("API_KEY")) {
        throw new Error("The AI analysis service is not configured. Please check API key.");
    }
    throw new Error("Failed to analyze ECG file. The AI model may be unavailable or the file may be unreadable.");
  }
};