
import { EcgReport } from '../types';

const HISTORY_KEY = 'ecgScanHistory';
const USER_ID_KEY = 'ecgAppUserId';

export const getUserId = (): string => {
  let userId = localStorage.getItem(USER_ID_KEY);
  if (!userId) {
    userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    localStorage.setItem(USER_ID_KEY, userId);
  }
  return userId;
};

export const getHistory = (): EcgReport[] => {
  try {
    const historyJson = localStorage.getItem(HISTORY_KEY);
    if (historyJson) {
      const reports: EcgReport[] = JSON.parse(historyJson);
      // Sort by timestamp descending (newest first)
      return reports.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }
  } catch (error) {
    console.error("Failed to parse history from localStorage", error);
    return [];
  }
  return [];
};

export const saveReport = (report: EcgReport): void => {
  const history = getHistory();
  const newHistory = [report, ...history];
  localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
};

export const deleteReport = (id: string): EcgReport[] => {
  const history = getHistory();
  const newHistory = history.filter(report => report.id !== id);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
  return newHistory;
};
