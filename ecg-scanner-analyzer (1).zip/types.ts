
export type ReportLevel = 'Normal' | 'Warning' | 'Critical' | 'Unknown';

export interface EcgReport {
  id: string;
  timestamp: string; // ISO 8601 string
  condition: string;
  confidence: number;
  emergencyProbability: number;
  heartRate: number;
  level: ReportLevel;
  fileName: string;
  fileDataUrl: string; // Base64 data URL of the scanned image
  fileType: string;
  summary: string;
  recommendation: string;
}

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}
