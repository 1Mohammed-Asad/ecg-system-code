
import React, { useState, useEffect, useCallback } from 'react';
import { BeforeInstallPromptEvent } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import ScannerPage from './components/ScannerPage';
import HistoryPage from './components/HistoryPage';
import { getUserId } from './services/storageService';
import Toast from './components/Toast';

export type Page = 'scanner' | 'history';

export default function App() {
    const [page, setPage] = useState<Page>('scanner');
    const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
    const [userId, setUserId] = useState('');
    const [toastMessage, setToastMessage] = useState('');

    useEffect(() => {
        setUserId(getUserId());
        
        const handleBeforeInstallPrompt = (e: Event) => {
            e.preventDefault();
            setInstallPrompt(e as BeforeInstallPromptEvent);
        };

        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        return () => {
            window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        };
    }, []);

    const handleInstallClick = () => {
        if (!installPrompt) return;
        installPrompt.prompt();
        installPrompt.userChoice.then(choiceResult => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the install prompt');
            } else {
                console.log('User dismissed the install prompt');
            }
            setInstallPrompt(null);
        });
    };
    
    const showToast = useCallback((message: string) => {
        setToastMessage(message);
        setTimeout(() => {
            setToastMessage('');
        }, 3000);
    }, []);

    return (
        <div className="min-h-screen bg-gray-900 text-white font-sans flex flex-col">
            <div className="container mx-auto p-4 md:p-6 lg:p-8 max-w-7xl flex-grow">
                <Header
                    currentPage={page}
                    onNavClick={setPage}
                    onInstallClick={handleInstallClick}
                    showInstallButton={!!installPrompt}
                    userId={userId}
                    showToast={showToast}
                />
                <main className="mt-8">
                    {page === 'scanner' ? <ScannerPage showToast={showToast} /> : <HistoryPage showToast={showToast} />}
                </main>
            </div>
            <Footer />
            {toastMessage && <Toast message={toastMessage} />}
        </div>
    );
}
